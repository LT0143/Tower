using System;
using System.Collections.Generic;
using System.Linq;

namespace UnityEditor.ShaderGraph.Drawing
{
    [AttributeUsage(AttributeTargets.Method)]
    class BuiltinKeywordAttribute : Attribute
    {
    }
}
