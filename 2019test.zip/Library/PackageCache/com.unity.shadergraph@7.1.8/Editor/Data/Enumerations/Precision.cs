﻿namespace UnityEditor.ShaderGraph.Internal
{
    enum Precision
    {
        Inherit,
        Float,
        Half,
    }

    public enum ConcretePrecision
    {
        Float,
        Half,
    }
}
