﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RenderMatrixMap : MonoBehaviour
{
    public static Vector2 sizeCube = new Vector2(0.5f, 0.5f); //放置平面的各个格子的间隙
    public Vector2 WHNums = new Vector2(35, 35);
    public Vector2[] shemeRadius; //相对于炮塔占用区域预制体位置
    public GameObject cubeMatrix;//占用区域预制体
    public GameObject[] radiusObject;//区域预制体，也就是plane的接受数组

    public List<PointMap> points = new List<PointMap>();//总的模拟地图位置列表
    public Material noActiveRegion;//不能搭建区域显示的材质
    public Material activeRegion;//能搭建区域显示的材质

    public bool CreateTower;


    //模拟大地图
    public void Start()
    {
        for (int x = 0; x < WHNums.x; x++)
        {
            for (int y = 0; y < WHNums.y; y++)
            {
                PointMap p = new PointMap(x * sizeCube.x, y * sizeCube.y, (x + 1) * sizeCube.x, (y + 1) * sizeCube.y);
                points.Add(p);
            }
        }
    }

    //public void OnDrawGizmos()
    //{
    //    Gizmos.color = Color.green;
    //    for (int i = 0; i < WHNums.x; i++)
    //    {
    //        for (int j = 0; j < WHNums.y; j++)
    //        {
    //            Gizmos.DrawSphere(new Vector3(i * sizeCube.x, 0, j * sizeCube.y), sizeCube.x);
    //        }
    //    }
    //}

    //刷新矩阵图标
    public void refreshMatrixCursor()
    {
        int shemeNum = shemeRadius.Length;
        radiusObject = new GameObject[shemeNum];
        Debug.Log("光标个数"+shemeRadius.Length);

        for (int i=0;i< shemeNum; i++)
        {
            radiusObject[i] = Instantiate(cubeMatrix, Vector3.zero, Quaternion.identity) as GameObject;
        }
    }


}
