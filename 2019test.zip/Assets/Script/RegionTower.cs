﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RegionTower : MonoBehaviour
{
    public Vector2[] returnMatrix;
    public int TypeRegion = 0;
   
    // Start is called before the first frame update
    public void Start()
    {
        if(TypeRegion ==0)
        {
            returnMatrix = standar_region();
        }
        else if(TypeRegion == 1)
        {
            returnMatrix = four_region();
        }else
        {
            returnMatrix = two_region();
        }
    }

    //区域设置
    public Vector2[] standar_region()
    {
        Vector2[] matrix = new Vector2[9];
        //x x x
        //x o x
        //x x x

        matrix[0] = new Vector2(-1, -1);
        matrix[1] = new Vector2(-1, 0);
        matrix[2] = new Vector2(-1, 1);

        matrix[3] = new Vector2(0, -1);
        matrix[4] = new Vector2(0, 1);

        matrix[5] = new Vector2(1, -1);
        matrix[6] = new Vector2(1, 0);
        matrix[7] = new Vector2(1, 1);

        matrix[8] = new Vector2(0, 0);
        return matrix;
    }

    public Vector2[] four_region()
    {
        Vector2[] matrix = new Vector2[6];
        //x x 
        //x o 
        //x x 

        matrix[0] = new Vector2(-1, -1);
        matrix[1] = new Vector2(-1, 0);
        matrix[2] = new Vector2(-1, 1);

        matrix[3] = new Vector2(0, -1);
        matrix[4] = new Vector2(0, 1);
        matrix[5] = new Vector2(0, 0);

        return matrix;
    }

    public Vector2[] two_region()
    {
        Vector2[] matrix = new Vector2[3];
        //x o x
        matrix[3] = new Vector2(-1, 0);
        matrix[4] = new Vector2(1, 0);
        matrix[5] = new Vector2(0, 0);

        return matrix;
    }
}
