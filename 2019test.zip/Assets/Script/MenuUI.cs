﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MenuUI : MonoBehaviour
{
    // Start is called before the first frame update
    void CreateTower( )
    {
       this.SendMessage("CreatTower","_tower1");
    }
 
}
