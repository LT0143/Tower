﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PointMap : MonoBehaviour
{
    public float x;
    public float y;
    public float sizeX;
    public float sizeY;

    public PointMap(float _x, float _y, float _sizeX, float _sizeY)
    {
        x = _x;
        y = _y;
        sizeX = _sizeX;
        sizeY = _sizeY;
    }

}
