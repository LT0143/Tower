﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tower : MonoBehaviour
{
    public GameObject[] towers;
    public MyCursor _Cursor;

    private GameObject tower;

    void CreatTower(string name )
    {
        switch(name)
        {
            case "tower1":
                tower = Instantiate(towers[0], new Vector3(0, 0, 0), Quaternion.identity) as GameObject;
                break;
            case "tower2":
                tower = Instantiate(towers[1], new Vector3(0, 0, 0), Quaternion.identity) as GameObject;
                break;
            case "tower3":
                tower = Instantiate(towers[2], new Vector3(0, 0, 0), Quaternion.identity) as GameObject;
                break;
        }

        if (tower != null){ 
            //初始化塔占地区域
            tower.GetComponent<RegionTower>().Start();
            //把初始化的占地区域复制给
            _Cursor.renderMatrixMap.shemeRadius = tower.GetComponent<RegionTower>().returnMatrix;
            _Cursor.createTower = tower;
            _Cursor.renderMatrixMap.refreshMatrixCursor();
        }
    }
 
}
